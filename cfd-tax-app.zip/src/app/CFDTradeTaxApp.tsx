import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Table, TableHead, TableHeader, TableRow, TableCell, TableBody } from "@/components/ui/table"

export default function CFDTradeTaxApp() {
  const [trades, setTrades] = useState([])
  const [tradeId, setTradeId] = useState("")
  const [date, setDate] = useState("")
  const [profitLoss, setProfitLoss] = useState("")
  const TAX_RATE = 0.206

  const addTrade = () => {
    if (!tradeId || !date || isNaN(parseFloat(profitLoss))) return
    const newTrade = {
      tradeId,
      date,
      profitLoss: parseFloat(profitLoss),
      tax: parseFloat(profitLoss) > 0 ? parseFloat(profitLoss) * TAX_RATE : 0,
    }
    setTrades([...trades, newTrade])
    setTradeId("")
    setDate("")
    setProfitLoss("")
  }

  const totalProfit = trades.reduce((sum, t) => sum + t.profitLoss, 0)
  const totalTax = trades.reduce((sum, t) => sum + t.tax, 0)

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">CFD Skatteberäkning för Aktiebolag</h1>

      <Card className="mb-6">
        <CardContent className="space-y-4 p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input placeholder="Trade ID" value={tradeId} onChange={e => setTradeId(e.target.value)} />
            <Input type="date" value={date} onChange={e => setDate(e.target.value)} />
            <Input placeholder="Vinst/Förlust (SEK)" value={profitLoss} onChange={e => setProfitLoss(e.target.value)} />
          </div>
          <Button onClick={addTrade}>Lägg till Trade</Button>
        </CardContent>
      </Card>

      {trades.length > 0 && (
        <>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Trade ID</TableHead>
                <TableHead>Datum</TableHead>
                <TableHead>Vinst/Förlust (SEK)</TableHead>
                <TableHead>Skatt (20,6%)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {trades.map((t, i) => (
                <TableRow key={i}>
                  <TableCell>{t.tradeId}</TableCell>
                  <TableCell>{t.date}</TableCell>
                  <TableCell>{t.profitLoss.toLocaleString("sv-SE", { style: "currency", currency: "SEK" })}</TableCell>
                  <TableCell>{t.tax.toLocaleString("sv-SE", { style: "currency", currency: "SEK" })}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          <div className="mt-4 text-right space-y-1">
            <div><strong>Total vinst/förlust:</strong> {totalProfit.toLocaleString("sv-SE", { style: "currency", currency: "SEK" })}</div>
            <div><strong>Total skatt:</strong> {totalTax.toLocaleString("sv-SE", { style: "currency", currency: "SEK" })}</div>
          </div>
        </>
      )}
    </div>
  )
}
