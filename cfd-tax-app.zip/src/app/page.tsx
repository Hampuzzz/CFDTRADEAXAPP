import CFDTradeTaxApp from "./CFDTradeTaxApp"

export default function Page() {
  return <CFDTradeTaxApp />
}
